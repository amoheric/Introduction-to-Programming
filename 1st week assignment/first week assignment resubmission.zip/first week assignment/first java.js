/*ERIC AMOH ADJEI
FIRST JS
5/14/22
*/
document.write("<p>Java Festival Days To Go</p><p>Check out! We have only ten seconds to begin, why not count 10 together...</p>")
var countdown = 10;

document.write("countdown in.." + countdown);
document.write("<br></br>");
countdown--;
document.write("countdown in.." + countdown);
document.write("<br></br>");
countdown--;
document.write("countdown in.." + countdown);
document.write("<br></br>");
countdown--;
document.write("countdown in.." + countdown);
document.write("<br></br>");
countdown--;
document.write("countdown in.." + countdown);
document.write("<br></br>");
countdown--;
document.write("countdown in.." + countdown);
document.write("<br></br>");
countdown--;
document.write("countdown in.." + countdown);
document.write("<br></br>");
countdown--;
document.write("countdown in.." + countdown);
document.write("<br></br>");
countdown--;
document.write("countdown in.." + countdown);
document.write("<br></br>");
countdown--;
document.write("countdown in.." + countdown);
document.write("<br></br>");
countdown--;
document.write("countdown in.." + countdown);
document.write("<br></br>");
countdown--;
document.write("Mission Control, We Have Blastoff!!!");
document.write("<br></br>");
countdown--;
alert("We Here To Blastoff Again")


